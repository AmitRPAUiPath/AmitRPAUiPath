import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message){
    def headers = message.getHeaders();
    def h_field1 = headers.get("field1");
    message.setHeader("field1", h_field1 + " (modified)");
   
    //def body = message.getBody();
    //def headers = message.getHeaders();
    //def value = headers.get("oldHeader");
    //message.setHeader("oldHeader", value + " modified");
    //message.setHeader("newHeader", "newHeader");
    //def properties = message.getProperties();
   // value = properties.get("oldProperty");
   // message.setProperty("oldProperty", value + " modified");
   // message.setProperty("newProperty", "newProperty");
    return message;
}